
package com.example.rizzassistant;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    String[] replies = {
            "Ke haal se 😎",
            "Tu badiya laagya manne 🔥",
            "Aaj bada active se 😄",
            "Teri vibe mast se 👀",
            "Kya scene hai aaj?"
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ListView listView = findViewById(R.id.replyList);

        ArrayAdapter<String> adapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_list_item_1,
                replies
        );

        listView.setAdapter(adapter);

        listView.setOnItemClickListener((parent, view, position, id) -> {
            String text = replies[position];

            ClipboardManager clipboard =
                    (ClipboardManager)getSystemService(Context.CLIPBOARD_SERVICE);

            ClipData clip = ClipData.newPlainText("reply", text);
            clipboard.setPrimaryClip(clip);

            Toast.makeText(this, "Copied 😄", Toast.LENGTH_SHORT).show();
        });
    }
}
